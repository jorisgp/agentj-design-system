import { ControlValueAccessor } from "@angular/forms";
import * as i0 from "@angular/core";
export type InputType = "text" | "email" | "password" | "number" | "tel" | "url";
export type InputSize = "sm" | "md" | "lg";
export declare class InputComponent implements ControlValueAccessor {
    type: import("@angular/core").InputSignal<InputType>;
    size: import("@angular/core").InputSignal<InputSize>;
    placeholder: import("@angular/core").InputSignal<string>;
    disabled: import("@angular/core").InputSignal<boolean>;
    readonly: import("@angular/core").InputSignal<boolean>;
    required: import("@angular/core").InputSignal<boolean>;
    label: import("@angular/core").InputSignal<string>;
    error: import("@angular/core").InputSignal<string>;
    hint: import("@angular/core").InputSignal<string>;
    valueChanged: import("@angular/core").OutputEmitterRef<string>;
    value: string;
    private onChange;
    private onTouched;
    onInput(event: Event): void;
    onBlur(): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(_isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputComponent, "agentjds-input", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; }, { "valueChanged": "valueChanged"; }, never, never, true, never>;
}
