import { ControlValueAccessor } from "@angular/forms";
import * as i0 from "@angular/core";
export interface InputRadioOption {
    label: string;
    value: string;
    disabled?: boolean;
}
export declare class InputRadioComponent implements ControlValueAccessor {
    label: import("@angular/core").InputSignal<string>;
    name: import("@angular/core").InputSignal<string>;
    options: import("@angular/core").InputSignal<InputRadioOption[]>;
    disabled: import("@angular/core").InputSignal<boolean>;
    required: import("@angular/core").InputSignal<boolean>;
    error: import("@angular/core").InputSignal<string>;
    hint: import("@angular/core").InputSignal<string>;
    valueChanged: import("@angular/core").OutputEmitterRef<string>;
    value: string;
    private generatedName;
    private formDisabled;
    private onChange;
    private onTouched;
    groupName(): string;
    isOptionDisabled(option: InputRadioOption): boolean;
    onSelectionChange(event: Event): void;
    onBlur(): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputRadioComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputRadioComponent, "agentjds-input-radio", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; }, { "valueChanged": "valueChanged"; }, never, never, true, never>;
}
