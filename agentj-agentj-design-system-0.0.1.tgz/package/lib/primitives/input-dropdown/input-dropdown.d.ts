import { ControlValueAccessor } from "@angular/forms";
import * as i0 from "@angular/core";
export type InputDropdownSize = "sm" | "md" | "lg";
export interface InputDropdownOption {
    label: string;
    value: string;
    disabled?: boolean;
}
export declare class InputDropdownComponent implements ControlValueAccessor {
    size: import("@angular/core").InputSignal<InputDropdownSize>;
    disabled: import("@angular/core").InputSignal<boolean>;
    required: import("@angular/core").InputSignal<boolean>;
    label: import("@angular/core").InputSignal<string>;
    error: import("@angular/core").InputSignal<string>;
    hint: import("@angular/core").InputSignal<string>;
    placeholder: import("@angular/core").InputSignal<string>;
    options: import("@angular/core").InputSignal<InputDropdownOption[]>;
    valueChanged: import("@angular/core").OutputEmitterRef<string>;
    value: string;
    private formDisabled;
    private onChange;
    private onTouched;
    isDisabled(): boolean;
    onSelectionChange(event: Event): void;
    onBlur(): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputDropdownComponent, "agentjds-input-dropdown", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; }, { "valueChanged": "valueChanged"; }, never, never, true, never>;
}
