import { ControlValueAccessor } from "@angular/forms";
import * as i0 from "@angular/core";
export declare class InputCheckboxComponent implements ControlValueAccessor {
    label: import("@angular/core").InputSignal<string>;
    disabled: import("@angular/core").InputSignal<boolean>;
    required: import("@angular/core").InputSignal<boolean>;
    error: import("@angular/core").InputSignal<string>;
    hint: import("@angular/core").InputSignal<string>;
    checkedChanged: import("@angular/core").OutputEmitterRef<boolean>;
    checked: boolean;
    private formDisabled;
    private onChange;
    private onTouched;
    isDisabled(): boolean;
    onCheckboxChange(event: Event): void;
    onBlur(): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputCheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputCheckboxComponent, "agentjds-input-checkbox", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; }, { "checkedChanged": "checkedChanged"; }, never, never, true, never>;
}
