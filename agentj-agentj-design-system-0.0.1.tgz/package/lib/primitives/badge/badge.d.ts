import * as i0 from "@angular/core";
export type BadgeVariant = "neutral" | "primary" | "success" | "warning" | "danger";
export type BadgeSize = "sm" | "md";
export declare class BadgeComponent {
    text: import("@angular/core").InputSignal<string>;
    variant: import("@angular/core").InputSignal<BadgeVariant>;
    size: import("@angular/core").InputSignal<BadgeSize>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeComponent, "agentjds-badge", never, { "text": { "alias": "text"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
