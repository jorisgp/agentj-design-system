import * as i0 from "@angular/core";
export type IconName = "close" | "check" | "info" | "warning" | "error" | "search" | "menu" | "arrow-down" | "arrow-up" | "star" | "plus" | "minus";
export type IconSize = "xs" | "sm" | "md" | "lg" | "xl";
export type IconColor = "primary" | "secondary" | "danger" | "success" | "warning" | "inherit";
export declare const ICON_PATHS: Record<IconName, string>;
export declare class IconComponent {
    name: import("@angular/core").InputSignal<IconName>;
    size: import("@angular/core").InputSignal<IconSize>;
    color: import("@angular/core").InputSignal<IconColor>;
    ariaLabel: import("@angular/core").InputSignal<string>;
    get path(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconComponent, "agentjds-icon", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "color": { "alias": "color"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
