import * as i0 from "@angular/core";
export type ButtonVariant = "primary" | "secondary" | "danger" | "ghost";
export type ButtonSize = "sm" | "md" | "lg";
export declare class ButtonComponent {
    type: import("@angular/core").InputSignal<"button" | "submit" | "reset">;
    variant: import("@angular/core").InputSignal<ButtonVariant>;
    size: import("@angular/core").InputSignal<ButtonSize>;
    disabled: import("@angular/core").InputSignal<boolean>;
    clicked: import("@angular/core").OutputEmitterRef<MouseEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "agentjds-button", never, { "type": { "alias": "type"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "clicked": "clicked"; }, never, ["*"], true, never>;
}
