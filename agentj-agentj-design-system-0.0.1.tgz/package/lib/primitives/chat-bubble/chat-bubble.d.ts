import * as i0 from "@angular/core";
export type ChatBubbleDirection = "incoming" | "outgoing";
export type ChatBubbleTone = "neutral" | "primary" | "success" | "warning";
export declare class ChatBubbleComponent {
    message: import("@angular/core").InputSignal<string>;
    author: import("@angular/core").InputSignal<string>;
    timestamp: import("@angular/core").InputSignal<string>;
    direction: import("@angular/core").InputSignal<ChatBubbleDirection>;
    tone: import("@angular/core").InputSignal<ChatBubbleTone>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatBubbleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatBubbleComponent, "agentjds-chat-bubble", never, { "message": { "alias": "message"; "required": false; "isSignal": true; }; "author": { "alias": "author"; "required": false; "isSignal": true; }; "timestamp": { "alias": "timestamp"; "required": false; "isSignal": true; }; "direction": { "alias": "direction"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
