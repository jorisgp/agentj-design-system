/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@agentj/agentj-design-system" />
export * from './index';
